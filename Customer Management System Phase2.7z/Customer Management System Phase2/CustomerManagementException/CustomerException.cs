﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerManagementException
{
    public class CustomerException : ApplicationException
    {
        public CustomerException() : base() { }
        public CustomerException(string msg) : base(msg) { }
        public CustomerException(string msg, Exception ex) : base(msg, ex) { }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CustomerManagementEntity;
using CustomerManagementException;
using CustomerManagementSystemBLL;

namespace Customer_Management_System_Phase2
{
    /// <summary>
    /// Interaction logic for AddCustomer.xaml
    /// </summary>
    public partial class AddCustomer : Window
    {
        
        public AddCustomer()
        {
            InitializeComponent();   
        }

        //On clicking ADD button, the details from window gets stored in customer variables
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Customer newCustomer = new Customer();
            try
            {
                newCustomer.Name = txtName.Text;
                newCustomer.City = txtCity.Text;
                newCustomer.Age = int.Parse(txtAge.Text);
                newCustomer.Phone = txtPhone.Text;
                newCustomer.Pincode = txtPincode.Text;

                CustomerManagementSystemBLL.CustomerBL.AddCustomerBL(newCustomer);
                MessageBox.Show("Customer Added");
                Clear();
               
            }catch(CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //After succesfull addition, the details entered in window gets cleared
        public  void Clear()
        {
            txtName.Text = "";
            txtCity.Text = "";
            txtAge.Text = "";
            txtPhone.Text = "";
            txtPincode.Text = "";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

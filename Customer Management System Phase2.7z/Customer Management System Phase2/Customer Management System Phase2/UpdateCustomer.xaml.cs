﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CustomerManagementEntity;
using CustomerManagementException;
using CustomerManagementSystemBLL;

namespace Customer_Management_System_Phase2
{
    /// <summary>
    /// Interaction logic for UpdateCustomer.xaml
    /// </summary>
    public partial class UpdateCustomer : Window
    {
        public UpdateCustomer(int id,string name,string city, int age,string phone,string pincode)
        {
            InitializeComponent();
            txtId.Text = id.ToString();
            txtName.Text = name;
            txtCity.Text = city;
            txtAge.Text = age.ToString();
            txtPhone.Text = phone;
            txtPincode.Text = pincode;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Customer updateCustomer=new Customer();
            int customerUpdated;

            try
            {
                updateCustomer.ID = int.Parse(txtId.Text);
                updateCustomer.Name = txtName.Text;
                updateCustomer.City = txtCity.Text;
                updateCustomer.Age = int.Parse(txtAge.Text);
                updateCustomer.Phone = txtPhone.Text;
                updateCustomer.Pincode = txtPincode.Text;
                customerUpdated = CustomerBL.UpdateCustomer(updateCustomer);
                if (customerUpdated > 0)
                {
                    MessageBox.Show("Customer Updated");
                }
                else
                    MessageBox.Show("Customer not Updated");
                this.Close();
            }
            catch(CustomerException ex) { MessageBox.Show("Customer with given ID not found"); }
            catch(SystemException ex) { MessageBox.Show("Enter valid values to the fields"); }
        }
    }
}

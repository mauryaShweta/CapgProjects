﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CustomerManagementEntity;
using CustomerManagementException;
using CustomerManagementSystemBLL;

namespace Customer_Management_System_Phase2
{
    /// <summary>
    /// Interaction logic for DeleteCustomer.xaml
    /// </summary>
    public partial class DeleteCustomer : Window
    {
        public DeleteCustomer()
        {
            InitializeComponent();
        }

        //Passing the ID of customer to be deleted to the Business layer
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int customerDeleted;
            try
            {
                int id = int.Parse(txtId.Text);
                customerDeleted= CustomerManagementSystemBLL.CustomerBL.DeleteCustomer(id);
                if (customerDeleted > 0)
                {
                    txtId.Text = "";
                    MessageBox.Show("Customer Deleted");
                }
                else
                    MessageBox.Show("Customer not Deleted");
                this.Close();
            }
            catch(CustomerException ex) { throw ex; }
            catch(SystemException ex) { throw ex; }
        }


       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace Customer_Management_System_Phase2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DataTable dataTable = null;
        public MainWindow()
        {
            InitializeComponent();
          
            gridView.DataContext = dataTable;
        }

        //Adding a Customer to the database
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddCustomer addCustomer = new AddCustomer();
            addCustomer.Show();
            
        }

        //Deleting the customer on the basis of ID from the database
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            DeleteCustomer deleteCustomer = new DeleteCustomer();
            deleteCustomer.Show();
        }

        //On clicking the search button Search window will open
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            SearchCustomer searchCustomer = new SearchCustomer();
            searchCustomer.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            
        }

        //On clicking the View Summary, the details of all customer will be displayed on the data grid
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
             dataTable = CustomerManagementSystemBLL.CustomerBL.DisplayCustomer();
            if (dataTable != null)
            {
                gridView.DataContext = dataTable;
               
            }
            else
                MessageBox.Show("No Customer present");
        }

        //On gridview, when the delete button is clicked then that customer gets removed from the database
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

            Button btn = sender as Button;
            int customerDeleted;
            int row;
            if (btn != null)
            {
                DataRowView dataRow = (DataRowView)gridView.SelectedItem;
                string cellValue = dataRow.Row.ItemArray[0].ToString();;
                customerDeleted = CustomerManagementSystemBLL.CustomerBL.DeleteCustomer(int.Parse(cellValue));
                DataTable dataTable = CustomerManagementSystemBLL.CustomerBL.DisplayCustomer();
                if (dataTable != null)
                {
                    MessageBox.Show("Customer Deleted");

                }

                gridView.DataContext = dataTable;
            }
            else
            {
                MessageBox.Show("Customer not Deleted");
            }
        }

        //On gridview, when the update button is clicked then customer update windows get displayed
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            Button btn = sender as Button;
            
            if (btn != null)
            {
                DataRowView dataRow = (DataRowView)gridView.SelectedItem;
                string id = dataRow.Row.ItemArray[0].ToString();
                string name = dataRow.Row.ItemArray[1].ToString();
                string city = dataRow.Row.ItemArray[2].ToString();
                string age = dataRow.Row.ItemArray[3].ToString();
                string phone = dataRow.Row.ItemArray[4].ToString();
                string pincode = dataRow.Row.ItemArray[5].ToString();

                UpdateCustomer updateCustomer = new UpdateCustomer(int.Parse(id), name, city, int.Parse(age), phone, pincode);
                updateCustomer.Show();
                DataTable dataTable = CustomerManagementSystemBLL.CustomerBL.DisplayCustomer();
                if (dataTable != null)
                {
                    gridView.DataContext = dataTable;
                }
                else
                    gridView.Items.Clear();
            }
            else
            {
                MessageBox.Show("Customer not Deleted");
            }
        }

    }
}

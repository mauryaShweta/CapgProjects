﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CustomerManagementEntity;
using CustomerManagementSystemBLL;
using CustomerManagementException;
using System.Data;

namespace Customer_Management_System_Phase2
{
    /// <summary>
    /// Interaction logic for SearchCustomer.xaml
    /// </summary>
    /// 
    public partial class SearchCustomer : Window
    {
        DataTable dataTable=null;
        public SearchCustomer()
        {
            InitializeComponent();
        }
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            int customerDeleted;
            int row;
            if (btn != null)
            {
                DataRowView dataRow = (DataRowView)SearchGrid.SelectedItem;
                string cellValue = dataRow.Row.ItemArray[0].ToString();
                //MessageBox.Show(cellValue);
                customerDeleted = CustomerManagementSystemBLL.CustomerBL.DeleteCustomer(int.Parse(cellValue));
                txtId.Text = "";
                DataTable dataTable = CustomerManagementSystemBLL.CustomerBL.SearchCustomerById(int.Parse(cellValue));
                if (dataTable != null)
                {
                    MessageBox.Show("Customer Deleted");
                    
                }
                
                SearchGrid.DataContext = dataTable;
            }
            else
            {
                MessageBox.Show("Customer not Deleted");
            }
            
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            int customerUpdated;
            int row;
            if (btn != null)
            {
                DataRowView dataRow = (DataRowView)SearchGrid.SelectedItem;
                string id = dataRow.Row.ItemArray[0].ToString();
                string name= dataRow.Row.ItemArray[1].ToString();
                string city = dataRow.Row.ItemArray[2].ToString();
                string age = dataRow.Row.ItemArray[3].ToString();
                string phone = dataRow.Row.ItemArray[4].ToString();
                string pincode = dataRow.Row.ItemArray[5].ToString();

                UpdateCustomer updateCustomer = new UpdateCustomer(int.Parse(id), name, city, int.Parse(age), phone, pincode);
                updateCustomer.Show();
                DataTable dataTable = CustomerManagementSystemBLL.CustomerBL.SearchCustomerById(int.Parse(id));
                if (dataTable != null)
                {
                    SearchGrid.DataContext = dataTable;
                }
                else
                    SearchGrid.Items.Clear();
            }
            else
            {
                MessageBox.Show("Customer not Deleted");
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                int id = int.Parse(txtId.Text);
                dataTable = CustomerManagementSystemBLL.CustomerBL.SearchCustomerById(id);
                if (dataTable != null)
                {
                    SearchGrid.DataContext = dataTable;
                }
                //SearchShowCustomer searchShowCustomer;
                //string searchedName = txtName.Text;
                //searchByname= CustomerBL.SearchCustomerByName(searchedName);
                if (dataTable != null)
                {
                    MessageBox.Show("Customer Found");
                    SearchGrid.DataContext = dataTable;
                    //searchShowCustomer = new SearchShowCustomer(searchByname);
                    //searchShowCustomer.Show();
                }
                else
                    MessageBox.Show("Customer not Found");
            }
            catch(CustomerException ex) { throw ex; }
            catch(SystemException ex) { throw ex; }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //Customer searchByname;
            DataTable dataTable;
            try
            {
              //  SearchShowCustomer searchShowCustomer;
                string searchedName = txtName.Text;
                 dataTable = CustomerManagementSystemBLL.CustomerBL.SearchCustomerByName(searchedName);
                if (dataTable != null)
                {
                    SearchGrid.DataContext = dataTable;

                }
                //SearchShowCustomer searchShowCustomer;
                //string searchedName = txtName.Text;
                //searchByname= CustomerBL.SearchCustomerByName(searchedName);
                if (dataTable != null)
                {
                    MessageBox.Show("Customer Found");
                    SearchGrid.DataContext = dataTable;
                    //searchShowCustomer = new SearchShowCustomer(searchByname);
                    //searchShowCustomer.Show();
                }
                else
                    MessageBox.Show("Customer not Found");
            }
            catch(CustomerException ex) { throw ex; }
            catch(SystemException ex) { throw ex; }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        //private void Button_Click_2(object sender, RoutedEventArgs e)
        //{
        //    Customer searchBycity;
        //    try
        //    {
        //        SearchShowCustomer searchShowCustomer;
        //        string searched = txtCity.Text;
        //        searchBycity = CustomerBL.SearchCustomerByCity(searched);
        //        if (searchBycity != null)
        //        {
        //            MessageBox.Show("Customer Found");
        //            searchShowCustomer = new SearchShowCustomer(searchBycity);
        //            searchShowCustomer.Show();
        //        }
        //        else
        //            MessageBox.Show("Customer not Found");
        //    }
        //    catch (CustomerException ex) { throw ex; }
        //    catch (SystemException ex) { throw ex; }
        //}
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CustomerManagementEntity;
using CustomerManagementException;
using System.Data;

namespace CustomerManagementSystemBLL
{
    public class CustomerBL
    {

        public static StringBuilder sb = null;
        public static int AddCustomerBL(Customer newCustomer)
        {
            int custInserted = 0;

            try
            {
                if (ValidateCustomer(newCustomer))
                {
                    custInserted = CustomerManagementDAL.CustomerDAL.AddCustomerDAL(newCustomer);
                }
                else
                    throw new CustomerManagementException.CustomerException("Customer data is invalid");
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custInserted;

        }

        public static bool ValidateCustomer(Customer newCust)

        {
            StringBuilder message = new StringBuilder();
            bool validCustomer = true;
            
            try
            {
                if (newCust.Name == string.Empty)
                {
                    message.Append("Customer name should be provided\n");
                    validCustomer = false;
                }

                else if (!Regex.IsMatch(newCust.Name, "^[A-Z][a-z]+"))
                {
                    message.Append("Customer name should start with Capital letter and it should have alphabets only\n");
                    validCustomer = false;
                }
                 
                if (newCust.City == string.Empty)
                {
                    message.Append("City should be provided\n");
                    validCustomer = false;
                }

                else if (!Regex.IsMatch(newCust.City, "^[A-Z][a-z]+"))
                {
                    message.Append("Customer city should start with Capital letter and it should have alphabets only\n");
                    validCustomer = false;
                }
                
                if (newCust.Age < 18)
                {
                    message.Append("Age should be greater that or equal to 18\n");
                    validCustomer = false;
                }

                if (newCust.Phone == String.Empty)
                {
                    message.Append("Phone number should be provided\n");
                    validCustomer = false;
                }
                else if (!Regex.IsMatch(newCust.Phone, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    validCustomer = false;
                }

                if (newCust.Pincode == string.Empty)
                {
                    message.Append("Pincode should be provided\n");
                    validCustomer = false;
                }

                else if (!Regex.IsMatch(newCust.Pincode, "[1-9][0-9]{5}"))
                {
                    message.Append("Pincode should have exactly 6 digits\n");
                    validCustomer = false;
                }

                if (validCustomer == false)
                {
                    throw new CustomerException(message.ToString());
                }
            }

            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validCustomer;

        }

        

        public static int UpdateCustomer(Customer custToBeUpdated)
        {
            int custUpdated = 0;

            try
            {
                if (ValidateCustomer(custToBeUpdated))
                {
                    custUpdated = CustomerManagementDAL.CustomerDAL.UpdateCustomer(custToBeUpdated);
                }
                else
                {
                    throw new CustomerException("Invalid Customer data for updation");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custUpdated;
        }

        public static int DeleteCustomer(int custID)
        {
            int custDeleted = 0;

            try
            {
                custDeleted = CustomerManagementDAL.CustomerDAL.DeleteCustomer(custID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custDeleted;
        }

        public static Customer SearchCustomer(int custID)
        {
            Customer custSearched = null;

            try
            {
                custSearched = CustomerManagementDAL.CustomerDAL.SearchCustomer(custID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custSearched;
        }

        public static Customer SearchCustomerByName(string searchedName)
        {
            Customer custSearched = null;

            try
            {
                custSearched = CustomerManagementDAL.CustomerDAL.SearchCustomerByName(searchedName);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custSearched;
        }

        public static Customer SearchCustomerByCity(string searchedCity)
        {
            Customer custSearched = null;

            try
            {
                custSearched = CustomerManagementDAL.CustomerDAL.SearchCustomerByCity(searchedCity);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custSearched;
        }


        public static DataTable DisplayCustomer()
        {
            DataTable dtCust = null;

            try
            {
                dtCust = CustomerManagementDAL.CustomerDAL.DisplayCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dtCust;
        }
    }
}

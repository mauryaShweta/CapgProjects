﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerManagementEntity;
using CustomerManagementException;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace CustomerManagementDAL
{
    public class CustomerDAL
    {
        public static SqlCommand CreateCommand()
        {

            SqlCommand cmd = null;
            SqlConnection con = null;
            try
            {
                con = new SqlConnection();
                string connString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
                con.ConnectionString = connString;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return cmd;
        }

        public static int AddCustomerDAL(Customer newCustomer)
        {
            int CustomerInserted = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_AddCustomer";
                cmd.Parameters.AddWithValue("@Name", newCustomer.Name);
                cmd.Parameters.AddWithValue("@City", newCustomer.City);
                cmd.Parameters.AddWithValue("@Age", newCustomer.Age);
                cmd.Parameters.AddWithValue("@Phone", newCustomer.Phone);
                cmd.Parameters.AddWithValue("@Pincode", newCustomer.Pincode);

                cmd.Connection.Open();
                CustomerInserted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return CustomerInserted;
        }




        public static DataTable DisplayCustomer()
        {
            DataTable dtCust = new DataTable();

            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_DisplayCustomer";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dtCust.Load(dr);
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dtCust;
        }

        public static Customer SearchCustomer(int custID)
        {
            Customer searchedCustomer = null;

            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_SearchCustomer";
                //cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@ID", custID);

                cmd.Connection.Open();
                SqlDataReader drCust = cmd.ExecuteReader();
                if (drCust.HasRows)
                {
                    searchedCustomer = new Customer();
                    drCust.Read();
                    searchedCustomer.ID = Convert.ToInt32(drCust["ID"]);
                    searchedCustomer.Name = drCust["Name"].ToString();
                    searchedCustomer.City = drCust["City"].ToString();
                    searchedCustomer.Age = Convert.ToInt32(drCust["Age"]);
                    searchedCustomer.Phone = drCust["Phone"].ToString();
                    searchedCustomer.Pincode = drCust["Pincode"].ToString();
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return searchedCustomer;
        }

        public static DataTable SearchCustomerById(int custID)
        {
            Customer searchedCustomer = null;
            DataTable dataTable = null;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_SearchCustomer";
                //cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@ID", custID);

                cmd.Connection.Open();
                SqlDataReader drCust = cmd.ExecuteReader();
                if (drCust.HasRows)
                {
                    dataTable = new DataTable();
                    dataTable.Load(drCust);
                   
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dataTable;
        }

        //public static DataTable DisplayCustomer()
        //{
        //    DataTable displayCustomer=null;
        //    try
        //    {
        //        SqlCommand cmd = CreateCommand();

        //        cmd.CommandText = "usp_DisplayCustomer";
        //        cmd.Connection.Open();
        //        SqlDataReader drCrust=cmd.ExecuteReader();
        //        if (drCrust.HasRows)
        //        {
        //            displayCustomer = new DataTable();
        //            displayCustomer.Load(drCrust);
        //        }
        //        cmd.Connection.Close();
        //    }
        //    catch(CustomerException ex) { throw ex; }
        //    catch(SystemException ex) { throw ex; }
        //    return displayCustomer;
        //}

        public static DataTable SearchCustomerByName(string SearchByname)
        {
            Customer searchedCustomer = null;
            DataTable dtCust = null;

            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_SearchCustomerByname";
                //cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@Name", SearchByname);

                cmd.Connection.Open();
                SqlDataReader drCust = cmd.ExecuteReader();
                if (drCust.HasRows)
                {
                    dtCust = new DataTable();
                    dtCust.Load(drCust);
                    //searchedCustomer = new Customer();
                    //drCust.Read();
                    //searchedCustomer.ID = Convert.ToInt32(drCust["ID"]);
                    //searchedCustomer.Name = drCust["Name"].ToString();
                    //searchedCustomer.City = drCust["City"].ToString();
                    //searchedCustomer.Age = Convert.ToInt32(drCust["Age"]);
                    //searchedCustomer.Phone = drCust["Phone"].ToString();
                    //searchedCustomer.Pincode = drCust["Pincode"].ToString();
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dtCust;
        }

        //public static Customer SearchCustomerByCity(string searchCity)
        //{
        //    Customer searchedCustomer = null;

        //    try
        //    {
        //        SqlCommand cmd = CreateCommand();
        //        cmd.CommandText = "usp_SearchCustomerBycity";
        //        //cmd.Parameters.Clear();
        //        cmd.Parameters.AddWithValue("@City", searchCity);

        //        cmd.Connection.Open();
        //        SqlDataReader drCust = cmd.ExecuteReader();
        //        if (drCust.HasRows)
        //        {
        //            searchedCustomer = new Customer();
        //            drCust.Read();
        //            searchedCustomer.ID = Convert.ToInt32(drCust["ID"]);
        //            searchedCustomer.Name = drCust["Name"].ToString();
        //            searchedCustomer.City = drCust["City"].ToString();
        //            searchedCustomer.Age = Convert.ToInt32(drCust["Age"]);
        //            searchedCustomer.Phone = drCust["Phone"].ToString();
        //            searchedCustomer.Pincode = drCust["Pincode"].ToString();
        //        }
        //        cmd.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return searchedCustomer;
        //}

        public static int UpdateCustomer(Customer custToBeUpdated)
        {
            int custUpdated = 0;

            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_UpdateCustomer";

                cmd.Parameters.AddWithValue("@ID", custToBeUpdated.ID);
                cmd.Parameters.AddWithValue("@Name", custToBeUpdated.Name);
                cmd.Parameters.AddWithValue("@City", custToBeUpdated.City);
                cmd.Parameters.AddWithValue("@Age", custToBeUpdated.Age);
                cmd.Parameters.AddWithValue("@Phone", custToBeUpdated.Phone);
                cmd.Parameters.AddWithValue("@Pincode", custToBeUpdated.Pincode);

                cmd.Connection.Open();
                custUpdated = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custUpdated;
        }

        public static int DeleteCustomer(int custID)
        {
            int custDeleted = 0;

            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_DeleteCustomer";

                cmd.Parameters.AddWithValue("@ID", custID);

                cmd.Connection.Open();
                custDeleted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custDeleted;
        }
    }
}
